// app/ThemeProvider.tsx
import React from 'react';
import { DefaultTheme, Provider as PaperProvider } from 'react-native-paper';

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#fa9c3e', // สีหลักของธีม
    accent: '#FFD700',
    background: '#FFFFFF',
    surface: '#FFFFFF',
    text: '#333333',
    disabled: '#E0E0E0',
    placeholder: '#A0A0A0',
    backdrop: '#000000',
  },
};

export const ThemeProvider = ({ children }) => {
  return <PaperProvider theme={theme}>{children}</PaperProvider>;
};
