import React from 'react';
export const DatabaseContext = React.createContext(null);